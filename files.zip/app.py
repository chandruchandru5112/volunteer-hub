"""Volunteer Opportunity Finder - local server.

Serves the single-page app in ./static/index.html using only the Python
standard library (no pip install needed).

Run:   python app.py
Open:  http://localhost:8000      (use --port to change)

All data (opportunities, registrations, history, profile) is stored in the
browser's localStorage, so it stays on the device that opens the app.
"""
import argparse
import functools
import http.server
import os
import socketserver
import webbrowser

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")


class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # Always fetch the latest file while developing
        self.send_header("Cache-Control", "no-store")
        super().end_headers()


def main():
    p = argparse.ArgumentParser(description="Run the Volunteer Opportunity Finder")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--no-browser", action="store_true", help="don't open a browser tab")
    a = p.parse_args()

    handler = functools.partial(Handler, directory=ROOT)
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer((a.host, a.port), handler) as httpd:
        url = f"http://{'localhost' if a.host == '127.0.0.1' else a.host}:{a.port}"
        print(f"Volunteer Opportunity Finder running at {url}  (Ctrl+C to stop)")
        if not a.no_browser:
            webbrowser.open(url)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopped.")


if __name__ == "__main__":
    main()
